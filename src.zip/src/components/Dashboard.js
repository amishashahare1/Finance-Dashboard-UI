import SummaryCard from "./SummaryCard";
import { LineChart, Line, XAxis, YAxis } from "recharts";

function Dashboard({ transactions }) {
  let income = 0;
  let expense = 0;

  transactions.forEach(t => {
    if (t.type === "income") income += t.amount;
    else expense += t.amount;
  });

  const balance = income - expense;

  const chartData = transactions.map((t, index) => ({
    name: index,
    amount: t.amount
  }));

  return (
    <div>
      <div className="dashboard">
        <SummaryCard title="Balance" value={balance} />
        <SummaryCard title="Income" value={income} />
        <SummaryCard title="Expense" value={expense} />
      </div>

      <h3>Balance Trend</h3>

      <LineChart width={400} height={250} data={chartData}>
        <XAxis dataKey="name" />
        <YAxis />
        <Line dataKey="amount" />
      </LineChart>
    </div>
  );
}

export default Dashboard;
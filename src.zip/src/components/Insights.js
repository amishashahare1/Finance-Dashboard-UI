function Insights({ transactions }) {
  let totalExpense = 0;
  let categoryMap = {};

  transactions.forEach(t => {
    if (t.type === "expense") {
      totalExpense += t.amount;
      categoryMap[t.category] =
        (categoryMap[t.category] || 0) + t.amount;
    }
  });

  let highestCategory = "";
  let max = 0;

  for (let cat in categoryMap) {
    if (categoryMap[cat] > max) {
      max = categoryMap[cat];
      highestCategory = cat;
    }
  }

  return (
    <div className="card">
      <h2>Insights</h2>
      <p>Total Expense: ₹{totalExpense}</p>
      <p>Top Category: {highestCategory}</p>
    </div>
  );
}

export default Insights;
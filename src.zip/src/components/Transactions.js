import { useState } from "react";

function Transactions({ transactions, setTransactions, role }) {
  const [search, setSearch] = useState("");

  // filter logic
  const filtered = transactions.filter(t =>
    t.category.toLowerCase().includes(search.toLowerCase())
  );

  // admin add function
  const addTransaction = () => {
    const newTxn = {
      id: Date.now(),
      date: "2026-03-10",
      amount: 1000,
      category: "Test",
      type: "expense"
    };

    setTransactions([...transactions, newTxn]);
  };

  return (
    <div>
      <h2>Transactions</h2>

      {/* Search box */}
      <input
        placeholder="Search category"
        onChange={(e) => setSearch(e.target.value)}
      />

      {/* Admin button */}
      {role === "admin" && (
        <button onClick={addTransaction}>Add Transaction</button>
      )}

      {/* List */}
      <ul>
        {filtered.map(t => (
          <li key={t.id}>
            {t.date} - {t.category} - ₹{t.amount} ({t.type})
          </li>
        ))}
      </ul>
    </div>
  );
}

export default Transactions;
const transactions = [
  { id: 1, date: "2026-03-01", amount: 5000, category: "Salary", type: "income" },
  { id: 2, date: "2026-03-02", amount: 2000, category: "Food", type: "expense" },
  { id: 3, date: "2026-03-03", amount: 1500, category: "Shopping", type: "expense" }
];

export default transactions;
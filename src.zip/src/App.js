 import "./App.css";
import { useState } from "react";

import Dashboard from "./components/Dashboard";
import Transactions from "./components/Transactions";
import RoleSwitcher from "./components/RoleSwitcher";
import Insights from "./components/Insights";

import data from "./data/transactions";
function App() {
  const [transactions, setTransactions] = useState(data);
  const [role, setRole] = useState("viewer");
  return (
    <div className="container">
      <h1>Finance Dashboard</h1>

      {/* Role Switch */}
      <RoleSwitcher role={role} setRole={setRole} />

      {/* Dashboard Cards */}
      <Dashboard transactions={transactions} />

      {/* Transactions Section */}
      <Transactions
        transactions={transactions}
        setTransactions={setTransactions}
        role={role}
      />

      {/* Insights Section */}
      <Insights transactions={transactions} />
    </div>
  );
}

export default App;